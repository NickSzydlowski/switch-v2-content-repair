//
//  Vector.h
//  Learning
//
//  Created by Matt Mays on Mon Dec 09 2002.
//  Copyright (c) 2002 Matt Mays. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import <GLUT/glut.h>
#import <Foundation/Foundation.h>

@class Atom, Universe;

@interface Vector : NSOpenGLView {

    id myAtom;
    float x, y, z;

}

-(id)initVector:(id)aAtom;

-(void)add:(id)thatVector;
-(void)subtract:(id)thatVector;
-(void)div:(id)vector1 vector:(id)vector2;
-(void)divBy:(float)value;
-(void)multiplyBy:(int)value;
-(id)absValue;

-(BOOL)isWithin:(float)value of:(id)thatVector;

-(float)x;
-(float)y;
-(float)z;

-(void)setTo:(id)thatVector;

-(void)setX:(float)newX Y:(float)newY Z:(float)newZ;

-(id)setX:(float)newX;
-(id)setY:(float)newY;
-(id)setZ:(float)newZ;

-(void)randomize;
-(void)reset;

@end

