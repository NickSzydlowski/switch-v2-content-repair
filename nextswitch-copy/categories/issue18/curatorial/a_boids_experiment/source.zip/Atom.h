//
//  Atom.h
//  SearchingForNothing_GLUT
//
//  Created by Matt Mays on Sat Oct 26 2002.
//  Copyright (c) 2002 Matt Mays. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import <GLUT/glut.h>
#import <Foundation/Foundation.h>

@class Universe, Vector;

@interface Atom : NSOpenGLView {

    id position;
    id velocity;

    id myUniverse;
    id myAtomArray;

    id cohesion;
    id separation;
    id alignment;
    id bound;
    id speed;

    float size;
}

// init
-initAtom:(id)myUniverse;

// accessors

-(int)size;
-(id)getPosition;
-(id)getVelocity;
-(id)myUniverse;

// boid operations
-(void)cohesion;
-(void)alignment;
-(void)separation;
-(void)bound;
-(void)speed;

// draw
-(void)drawMe;

// move
-(void)moveMe;

// reset
-(void)reset;


@end

