//
//  Universe.h
//  SearchingForNothing_GLUT
//
//  Created by Matt Mays on Mon Oct 28 2002.
//  Copyright (c) 2002 Matt Mays. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import <GLUT/glut.h>
#import <Foundation/Foundation.h>

@interface Universe : NSOpenGLView {
    NSMutableArray *atomArray;

    int cohesionFactor;
    int alignmentFactor;
    int atomSize;
    int worldSize;
    int birthRange;
    int gravity;
    int numberOfAtoms;
    float collisionField;
}

-(void)rebirth;
-(int)count;
-(id)initUniverse;
-(id)atomArray;
-(void)moveAllAtoms;
-(void)drawAllAtoms;
-(void)moveCamera:(id)centerOfMass;

-(float)collisionField;
-(int)cohesionFactor;
-(float)alignmentFactor;
-(int)atomSize;
-(int)worldSize;
-(int)birthRange;
-(int)gravity;

@end

