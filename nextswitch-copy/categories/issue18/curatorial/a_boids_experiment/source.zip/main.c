//
//  main.m
//  SearchingForNothing_GLUT
//
//  Created by Matt Mays on Sat Oct 26 2002.
//  Copyright (c) 2002 __MyCompanyName__. All rights reserved.
//

#include <Cocoa/Cocoa.h>
#include <GLUT/glut.h>
#include <OpenGL/gl.h>
#include <OpenGL/glu.h>

#define kWindowWidth	400
#define kWindowHeight	300

static GLfloat spin = 0.0;

void drawSelf(void)
{
    // Clear the screen and depth buffer
    glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );

    glLoadIdentity();   // Reset the current modelview matrix

    glColor3f(0.0, 0.0, 1.0);

    glPushMatrix();

        glTranslatef(0.0 , 0.0, -3.0);
        glRotatef(spin, 0.0, 1.0, 0.0);
        glutWireSphere(1.0, 20, 16);

        glLoadIdentity();

        glTranslatef(2.0 , 0.0, -6.0);
        glRotatef(spin, 0.0, 0.0, 1.0);
        glutWireSphere(1.0, 20, 16);

    glPopMatrix();

    glutSwapBuffers();
}

void spinAtoms(void)
{
    spin = spin + 1.0;
    if (spin > 360.0)
        spin = spin - 360.0;
    glutPostRedisplay();
}

void reshape(int w, int h)
{
    glViewport(0, 0, (GLsizei) w, (GLsizei) h);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective(60.0, (GLfloat) w/(GLfloat) h, 1.0, 20.0);
    glMatrixMode(GL_MODELVIEW);
}

void init(void)
{
    glShadeModel( GL_SMOOTH );                // Enable smooth shading
    glClearColor( 0.0f, 0.0f, 0.0f, 0.5f );   // Black background
    glClearDepth( 1.0f );                     // Depth buffer setup
    glEnable( GL_DEPTH_TEST );                // Enable depth testing
    glDepthFunc( GL_LEQUAL );                 // Type of depth test to do


}

int main(int argc, char** argv)
{
    glutInit(&argc, argv);
    glutInitDisplayMode (GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
    glutInitWindowSize (kWindowWidth, kWindowHeight);
    glutInitWindowPosition (100, 100);
    glutCreateWindow (argv[0]);

    init();

    glutDisplayFunc(drawAtom);
    glutReshapeFunc(reshape);
    glutIdleFunc(spinAtoms);
    glutMainLoop();

    return 0;
}

