. . . . a BOIDS experiment by matt mays <boids@cosmodrome.com>

"boids" is an aglorithm for simulating flocking behavior originally 
developed by Craig Reynolds
http://www.red3d.com/cwr/boids/
this code is based on the boids psuedocode by Conrad Parker
http://www.vergenet.net/~conrad/boids/pseudocode.html
and influenced by C++ boids by Christopher Kline
http://www.media.mit.edu/~ckline/cornellwww/boid/boids.html
. . . . other notes
written in objective-C
Project Builder and OS X executables included in this directory
velocity is still out of whack but it looks ok anyway
also code intact for sphere cage simulation
don't make fun of my code, i've just started OOP
press r to reset or wait 3 seconds
