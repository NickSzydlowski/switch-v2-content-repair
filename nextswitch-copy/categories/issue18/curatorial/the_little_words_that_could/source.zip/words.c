#include <stdio.h>
#include<stdlib.h>
#include<GL/glut.h>
#include <string.h>



// Declare value of spheres at start
static GLfloat sSphere = 0.2;
static GLfloat sSpherea = 0.002;
static GLfloat sSphereb = 0.002;
static GLfloat sSpherec = 0.002;
static GLfloat sSphered = 0.002;
static GLfloat sSpheree = 0.002;
static GLfloat sSpheref = 0.002;
static GLfloat sSphereg = 0.002;
static GLfloat sSphereh = 0.002;

// Declare location of spheres at start
static float cir1x = -2.0;
static float cir1y = 0.0;
static float cir2x = -1.0;
static float cir2y = 0.0;
static float cir3x = 0.0;
static float cir3y = 0.0;
static float cir4x = 1.0;
static float cir4y = 0.0;
static float cir5x = 2.0;
static float cir5y = 0.0;


// Declare amount sphere is moved
static float movecir1 = 0;
static float movecir2 = 0;
static float movecir3 = 0;
static float movecir4 = 0;
static float movecir5 = 0;





// Declare location of displayed letters
static float spletterx;
static float splettery;

void *font = GLUT_STROKE_ROMAN;


//Declares counting variables
char c[10];

int k;

FILE *fp1;

int count_a = 0;
int count_b = 0;
int count_c = 0;
int count_d = 0;
int count_e = 0;
int count_f = 0;
int count_g = 0;
int count_h = 0;

//Not used
static float spin = 0.0;
static float zoom = 0.0;

// temp variable
int b = 0;


int counttext();



// Declare functions
void counting(void);
void Display(void);

void moveamount1(void);
void moveamount2(void);
void moveamount3(void);
void moveamount4(void);
void moveamount5(void);

void checkloc1(void);
void checkloc2(void);
void checkloc3(void);
void checkloc4(void);
void checkloc5(void);

void numgen(void);
void movex(void);
void constrain(void);




//Declare searched letters (now complete words)
char letter1[10], letter2[10], letter3[10], letter4[10], letter5[10], letter6[10], letter7[10], letter8[10];







//Hardcore counting word function

void counting(void)
{
  //FILE *fp1;
  char filename[25];
  
  int k = 0;

  if (b==0)
  {
    printf("Enter filename: ");
    scanf("%s", filename);

    printf("Enter word1: ");
    scanf("%s", letter1);

    printf("Enter word2: ");
    scanf("%s", letter2);

    printf("Enter word3: ");
    scanf("%s", letter3);

    printf("Enter word4: ");
    scanf("%s", letter4);

    printf("Enter word5: ");
    scanf("%s", letter5);


// Now only 5 words
//    printf("Enter word6: ");
//    scanf("%s", letter6);

//    printf("Enter word7: ");
//    scanf("%s", letter7);

//    printf("Enter word8: ");
//    scanf("%s", letter8);


    fp1 = fopen(filename, "r");
    b = 1;
  }
 

//     while (c != EOF) {
//	while (c != '\n') 


   for (k=0; k<10;k++)
   {
     c[k] = getc(fp1);  // get initial input /
     if (c[k] == NULL)
     {
        printf("file error!");
        exit(0);
     }   
     
     if(c[k] == ' ')
     {
         c[k] = NULL;
         break;  
     }  
} 

     if (strcmp(c, letter1) ==0)

        count_a ++;
 
     if (strcmp(c, letter2) ==0)
        count_b ++;

     if (strcmp(c, letter3) ==0)
        count_c ++;

     if (strcmp(c, letter4) ==0)
        count_d ++;

     if (strcmp(c, letter5) ==0)
        count_e ++;
 

// Now only 5 words
//     if (strcmp(c, letter6) ==0)
//        count_f ++;

//     if (strcmp(c, letter7) ==0)
//        count_g ++;

//     if (strcmp(c, letter8) ==0)
//        count_h ++; 
   


// Display count in Unix Shell

   printf("total %s is %i\n", letter1, count_a);
   printf("total %s is %i\n", letter2, count_b);


  printf("total %s is %i\n", letter3, count_c);
  printf("total %s is %i\n", letter4, count_d);
  printf("total %s is %i\n", letter5, count_e);
//  printf("total %s is %i\n", letter6, count_f);
//  printf("total %s is %i\n", letter7, count_g);
//  printf("total %s is %i\n", letter8, count_h);

  //glutPostRedisplay();
  // repeat until NULL    
  //   fclose(fp1);
}




static int leftright = 0, updown = 0;




void init(void) 
{
   glClearColor (0.5, 0.5, 0.5, 1.0);
   glShadeModel (GL_FLAT);



}

void display(void)
{


Display();

  glClear(GL_COLOR_BUFFER_BIT);
  glClearColor (0.7, 0.7, 0.7, 1.0);
glLoadIdentity ();             /* clear the matrix */
           /* viewing transformation  */
   gluLookAt (0.0, 0.0, 10.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0);



  
  










//1 - set of main letters to intersect with



glPushMatrix();
glTranslatef(spletterx, splettery, -90);

//glColor3f(0, rand()*.002, rand()*.002);

glColor3f(1, 0, 0);

glScalef(zoom,zoom,1);



glutStrokeCharacter(font, c[k]);
glPopMatrix();



//2-nonintersect Environmental letters

glPushMatrix();
glTranslatef(spletterx- 20, splettery-5, -90);
glColor3f(.3, .2, .2);
glScalef(zoom,zoom,1);
glutStrokeCharacter(font, c[k]);
glPopMatrix();



//3-nonintersect Environmental letters

glPushMatrix();
glTranslatef(spletterx + 15, splettery+15, -90);
glColor3f(.3, .2, .2);
glScalef(zoom,zoom,1);
glutStrokeCharacter(font, c[k]);
glPopMatrix();


// spheres

glPushMatrix(); 			// 1
  glColor3f(.2 + count_a*.02, .2 + count_a*.02, .2 + count_a*.02);
  glRotatef(0, 0.0, 0.0, 1.0);
  glTranslatef(cir1x, cir1y, 0);
  glutSolidSphere(sSpherea, 30, 30);
  glPopMatrix();  


glPushMatrix(); 			// 2
  glColor3f(.2 + count_b*.02, .2 + count_b*.02, .2 + count_b*.02);
  glRotatef(0, 0.0, 0.0, 1.0);
  glTranslatef(cir2x, cir2y, 0);
  glutSolidSphere(sSphereb, 30, 30);
  glPopMatrix();


glPushMatrix(); 			// 3
  glColor3f(.2 + count_c*.02, .2 + count_c*.02, .2 + count_c*.02);
  glRotatef(0, 0.0, 0.0, 1.0);
  glTranslatef(cir3x, cir3y, 0);
  glutSolidSphere(sSpherec, 30, 30);
  glPopMatrix();

glPushMatrix(); 			// 4
  glColor3f(.2 + count_d*.02, .2 + count_d*.02, .2 + count_d*.02);
  glRotatef(0, 0.0, 0.0, 1.0);
  glTranslatef(cir4x, cir4y, 0);
  glutSolidSphere(sSphered, 30, 30);
  glPopMatrix();


glPushMatrix(); 			// 5
  glColor3f(.2 + count_e*.02, .2 + count_e*.02, .2 + count_e*.02);
  glRotatef(0, 0.0, 0.0, 1.0);
  glTranslatef(cir5x, cir5y, 0);
  glutSolidSphere(sSpheree, 30, 30);
  glPopMatrix();



// Now only 5 words used

//glPushMatrix(); 			// 6
//  glColor3f(.2 + count_f*.02, .2 + count_f*.02, .2 + count_f*.02);
//  glRotatef(0, 0.0, 0.0, 1.0);
//  glTranslatef(1.4, -1.4, 0);
//  glutSolidSphere(sSpheref, 30, 30);
//  glPopMatrix();



//glPushMatrix(); 			// 7
//  glColor3f(.2 + count_g*.02, .2 + count_g*.02, .2 + count_g*.02);
//  glRotatef(0, 0.0, 0.0, 1.0);
//  glTranslatef(0, -2, 0);
//  glutSolidSphere(sSphereg, 30, 30);
//  glPopMatrix();




//glPushMatrix(); 			// 8
//  glColor3f(.2 + count_h*.02, .2 + count_h*.02, .2 + count_h*.02);
//  glRotatef(0, 0.0, 0.0, 1.0);
//  glTranslatef(-1.4, -1.4, 0);
//  glutSolidSphere(sSphereh, 30, 30);
//  glPopMatrix();



 glutSwapBuffers();

}



// Long list of functions checking intersecting

void checkloc5(void)
{

//circle 5


if ((splettery - cir5y <0) && (splettery - cir5y >-15) && (spletterx - cir5x <0) && (spletterx - cir5x >-30))
		{		
		
		cir5y = (cir5y + movecir5);
		
		}



if ((splettery - cir5y <0) && (splettery - cir5y >-30) && (spletterx - cir5x <0) && (spletterx - cir5x >-15))
		{		
		cir5x = (cir5x + movecir5);
		
		
		}


if ((splettery - cir5y >.1) && (splettery - cir5y <15) && (spletterx - cir5x >.1)  && (spletterx - cir5x <30))
		{		
		
		cir5y = (cir5y - movecir5);
		
		}	



if ((splettery - cir5y >.1) && (splettery - cir5y <30) && (spletterx - cir5x >.1)  && (spletterx - cir5x <15))
		{		
		cir5x = (cir5x - movecir5);
		
		}


}




void checkloc4(void)
{

//circle 4


if ((splettery - cir4y <0) && (splettery - cir4y >-15) && (spletterx - cir4x <0) && (spletterx - cir4x >-30))
		{		
		
		cir4y = (cir4y - movecir4);
		
		}



if ((splettery - cir4y <0) && (splettery - cir4y >-30) && (spletterx - cir4x <0) && (spletterx - cir4x >-15))
		{		
		cir4x = (cir4x + movecir4);
		
		
		}


if ((splettery - cir4y >.1) && (splettery - cir4y <15) && (spletterx - cir4x >.1)  && (spletterx - cir4x <30))
		{		
		
		cir4y = (cir4y - movecir4);
		
		}	



if ((splettery - cir4y >.1) && (splettery - cir4y <30) && (spletterx - cir4x >.1)  && (spletterx - cir4x <15))
		{		
		cir4x = (cir4x + movecir4);
		
		}		
	

}




void checkloc3(void)
{

//circle 3


if ((splettery - cir3y <0) && (splettery - cir3y >-15) && (spletterx - cir3x <0) && (spletterx - cir3x >-30))
		{		
		
		cir3y = (cir3y + movecir3);
		
		}



if ((splettery - cir3y <0) && (splettery - cir3y >-30) && (spletterx - cir3x <0) && (spletterx - cir3x >-15))
		{		
		cir3x = (cir3x - movecir3);
		
		
		}


if ((splettery - cir3y >.1) && (splettery - cir3y <15) && (spletterx - cir3x >.1)  && (spletterx - cir3x <15))
		{		
		
		cir3y = (cir3y - movecir3);
		
		}	



if ((splettery - cir3y >.1) && (splettery - cir3y <30) && (spletterx - cir3x >.1)  && (spletterx - cir3x <5))
		{		
		cir3x = (cir3x + movecir3);
		
		}


}






void checkloc2(void)
{
//circle 2


if ((splettery - cir2y <0) && (splettery - cir2y >-15) && (spletterx - cir2x <0) && (spletterx - cir2x >-30))
		{		
		
		cir2y = (cir2y + movecir2);
		
		}



if ((splettery - cir2y <0) && (splettery - cir2y >-30) && (spletterx - cir2x <0) && (spletterx - cir2x >-15))
		{		
		cir2x = (cir2x + movecir2);
		
		
		}


if ((splettery - cir2y >.1) && (splettery - cir2y <15) && (spletterx - cir2x >.1)  && (spletterx - cir2x <30))
		{		
		
		cir2x = (cir2x - movecir2);
		
		}	



if ((splettery - cir2y >.1) && (splettery - cir2y <30) && (spletterx - cir2x >.1)  && (spletterx - cir2x <15))
		{		
		cir2y = (cir2y - movecir2);
		
		}
}






void checkloc1(void)
{
//start



//circle 1


if ((splettery - cir1y <0) && (splettery - cir1y >-15) && (spletterx - cir1x <0) && (spletterx - cir1x >-30))
		{		
		
		cir1x = (cir1x - movecir1);
		
		}



if ((splettery - cir1y <0) && (splettery - cir1y >-30) && (spletterx - cir1x <0) && (spletterx - cir1x >-15))
		{		
		cir1y = (cir1y + movecir1);
		
		
		}


if ((splettery - cir1y >.1) && (splettery - cir1y <15) && (spletterx - cir1x >.1)  && (spletterx - cir1x <30))
		{		
		
		cir1y = (cir1y - movecir1);
		
		}	



if ((splettery - cir1y >.1) && (splettery - cir1y <30) && (spletterx - cir1x >.1)  && (spletterx - cir1x <15))
		{		
		cir1x = (cir1x - movecir1);
		
		}


//end
}






void moveamount1(void)

{
if ((count_a > 1) && (count_a < 10))
{	
movecir1 = .7;
}

else if ((count_a > 10) && (count_a < 16))
{
	movecir1 = .4;
}

else if ((count_a > 16) && (count_a < 25))
{
	movecir1 = .25;
}

else if ((count_a > 25) && (count_a < 35))
{
	movecir1 = .1;

}

else if ((count_a > 35) && (count_a < 50))
{
	movecir1 = .01;

}

}



void moveamount2(void)

{
if ((count_b > 1) && (count_b < 10))
{	
movecir2 = .7;
}

else if ((count_b > 10) && (count_b < 16))
{
	movecir2 = .4;
}

else if ((count_b > 16) && (count_b < 25))
{
	movecir2 = .25;
}

else if ((count_b > 25) && (count_b < 35))
{
	movecir2 = .1;

}

else if ((count_b > 35) && (count_b < 50))
{
	movecir2 = .01;

}

}




void moveamount3(void)

{
if ((count_c > 1) && (count_c < 10))
{	
movecir3 = .7;
}

else if ((count_c > 10) && (count_c < 16))
{
	movecir3 = .4;
}

else if ((count_c > 16) && (count_c < 25))
{
	movecir3 = .25;
}

else if ((count_c > 25) && (count_c < 35))
{
	movecir3 = .1;

}

else if ((count_c > 35) && (count_c < 50))
{
	movecir3 = .01;

}

}



void moveamount4(void)

{
if ((count_d > 1) && (count_d < 10))
{	
movecir4 = .7;
}

else if ((count_d > 10) && (count_d < 16))
{
	movecir4 = .4;
}

else if ((count_d > 16) && (count_d < 25))
{
	movecir4 = .25;
}

else if ((count_d > 25) && (count_d < 35))
{
	movecir4 = .1;

}

else if ((count_d > 35) && (count_d < 50))
{
	movecir4 = .01;

}

}





void moveamount5(void)

{
if ((count_e > 1) && (count_e < 10))
{	
movecir5 = .7;
}

else if ((count_e > 10) && (count_e < 16))
{
	movecir5 = .4;
}

else if ((count_e > 16) && (count_e < 25))
{
	movecir5 = .25;
}

else if ((count_e > 25) && (count_e < 35))
{
	movecir5 = .1;

}

else if ((count_e > 35) && (count_e < 50))
{
	movecir5 = .01;

}

}





// make locations of letters

void numgen(void)
{
spletterx = rand()*.002-32;
splettery = rand()*.002-32;

}



// boundaries for spheres

void constrain(void)
{
if (cir1x > 2.5)
	cir1x = (cir1x - .5);

if (cir1x < -2.5)
	cir1x = (cir1x + .5);

if (cir1y > 2.5)
	cir1y = (cir1y - .5);

if (cir1y < -2.5)
	cir1y = (cir1y + .5);



if (cir2x > 2.5)
	cir2x = (cir2x - .5);

if (cir2x < -2.5)
	cir2x = (cir2x + .5);

if (cir2y > 2.5)
	cir2y = (cir2y - .5);

if (cir2y < -2.5)

	cir2y = (cir2y + .5);



if (cir3x > 2.5)
	cir3x = (cir3x - .5);

if (cir3x < -2.5)
	cir3x = (cir3x + .5);

if (cir3y > 2.5)
	cir3y = (cir3y - .5);

if (cir3y < -2.5)
	cir3y = (cir3y + .5);



if (cir4x > 2.5)
	cir4x = (cir4x - .5);

if (cir4x < -2.5)
	cir4x = (cir4x + .5);

if (cir4y > 2.5)
	cir4y = (cir4y - .5);

if (cir4y < -2.5)
	cir4y = (cir4y + .5);


if (cir5x > 2.5)
	cir5x = (cir5x - .5);

if (cir5x < -2.5)
	cir5x = (cir5x + .5);

if (cir5y > 2.5)
	cir5y = (cir5y - .5);

if (cir5y < -2.5)
	cir5y = (cir5y + .5);

}







void Display (void)
{
spin = spin + 0.2;
if (spin > 3.0)
	spin=-3;





zoom = zoom + .005;
if (zoom > 0.05)
	zoom=0;



numgen();

constrain();

counting();

checkloc1();
checkloc2();
checkloc3();
checkloc4();
checkloc5();

moveamount1();
moveamount2();
moveamount3();
moveamount4();
moveamount5();


//sSphere= sSphere + 0.4;
//   if (sSphere > 0.7)
//      sSphere = 0;



// grow spheres

 if (count_a > 1)
sSpherea= count_a*.035;
  
      

if (count_b > 1)
sSphereb=   count_b*.035;
  




 if (count_c > 1)
sSpherec= count_c*.035;
  
      

if (count_d > 1)
sSphered=   count_d*.035;
  

 if (count_e > 1)
sSpheree= count_e*.035;
  
      

if (count_f > 1)
sSpheref=   count_f*.035;


 if (count_g > 1)
sSphereg= count_g*.035;
  
      

if (count_h > 1)
sSphereh= count_h*.035;
  



      



glutPostRedisplay();

}





void sizeSphere(void)
{
//   sSphere= sSphere + 0.004;
//   if (sSphere > 6.0)
//      sSphere = sSphere - 5.0;
//   glutPostRedisplay();
}












void myReshape(int w, int h)
{
  glViewport(0, 0, w, h);
  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();
  gluPerspective(30, (GLfloat) w/(GLfloat) h, 1.0, 100.0);
  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();
  gluLookAt(0, 0, 10, 0, 0, 0, 0, 1, 0);
}


void mouse(int button, int state, int x, int y)
{switch (button) {
    case GLUT_LEFT_BUTTON:
       if(state == GLUT_DOWN)
       glutIdleFunc (Display);
 break;
     case GLUT_MIDDLE_BUTTON:
       if (state == GLUT_DOWN)
       glutIdleFunc(NULL);
 break;

default: 
break;

}
}


int main(int argc, char** argv)
{
  
  glutInit(&argc, argv);
  glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB);
  glutInitWindowSize(850,850);
  glutInitWindowPosition(100,100);
  glutCreateWindow("sphere thing");
  glutReshapeFunc(myReshape);
glutIdleFunc (display);
  glutDisplayFunc(display);





// glutMouseFunc(mouse);

  glutMainLoop();
  return 0;
}

