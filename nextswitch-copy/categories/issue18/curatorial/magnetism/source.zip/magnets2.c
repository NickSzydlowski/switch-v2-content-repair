#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <GL/glut.h>
#include <math.h>


enum {
    SCROLL_LEFT = 1,
    SCROLL_RIGHT,
    SCROLL_UP,
    SCROLL_DOWN
} type = SCROLL_RIGHT;


typedef struct _clump {
    float pos[3];
    float vel[3];   //velocity
    float acc[3];   //acceleration
    float mass;     //mass
} clump;



float ep = 0.005;

float x1, x2, x3;

double d;

int n = 8;       //NUMBER OF GROUPED OBJECTS TO BEGIN WITH
int object = 500;   //DENSITY OF OBJECT (0 = less 5000 = more)

clump **obj;
clump *s;

int h, w;
int spin_x=0, spin_y=0, old_x = 0, old_y = 0;
int move_z = 0;
int spin_z = -1500;

void init();


// MOVES CENTER OF CLUMP WHICH MOVES ENTIRE OBJECT
void moveclump(void) {
    int i, j;
    float ep_t_mass;

    for(i = 0; i < n; i++) {
        for(j = 0; j< n; j++) {

            if(j == i)
                continue;
    
            x1 = s[i].pos[0] - s[j].pos[0];
            x2 = s[i].pos[1] - s[j].pos[1];
            x3 = s[i].pos[2] - s[j].pos[2];

            d = sqrt (x1*x1 + x2*x2 + x3*x3);
    
            if(d > 10)
                ep_t_mass = -ep*s[j].mass/(d*d);
            else
                ep_t_mass = 0;
            
            s[i].acc[0] = ep_t_mass * x1; 
            s[i].acc[1] = ep_t_mass * x2;
            s[i].acc[2] = ep_t_mass * x3;

            s[i].vel[0] += s[i].acc[0];
            s[i].vel[1] += s[i].acc[1];
            s[i].vel[2] += s[i].acc[2];

            s[i].pos[0] += s[i].vel[0];
            s[i].pos[1] += s[i].vel[1];
            s[i].pos[2] += s[i].vel[2];
                                  
        }
    }
}
// MOVES INDIVIDUAL POINTS WITHIN OBJECT
void move(void) {
    int i, j, k;
    float ep_t_mass;


    for(j = 0; j < n; j++) {
           for(i = 0; i < object; i++) {
               for(k = 0; k < n; k++) {

                 x1 = obj[j][i].pos[0] - s[k].pos[0];
                x2 = obj[j][i].pos[1] - s[k].pos[1];
                x3 = obj[j][i].pos[2] - s[k].pos[2];
    
                d = sqrt (x1*x1 + x2*x2 + x3*x3);
        
                if(d > 10)
                    ep_t_mass = -ep*s[k].mass/(d*d);
                else 
                    ep_t_mass = 0;
                
                obj[j][i].acc[0] = ep_t_mass * x1;
                obj[j][i].acc[1] = ep_t_mass * x2;
                obj[j][i].acc[2] = ep_t_mass * x3;

                obj[j][i].vel[0] += obj[j][i].acc[0];
                obj[j][i].vel[1] += obj[j][i].acc[1];
                obj[j][i].vel[2] += obj[j][i].acc[2];
    
                obj[j][i].pos[0] += obj[j][i].vel[0];
                obj[j][i].pos[1] += obj[j][i].vel[1];
                obj[j][i].pos[2] += obj[j][i].vel[2];
                                  
            }
        }
    }
}

void
reshape(int width, int height)
{

    h = height;
    w = width;

    glViewport(0, 0, width, height);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    //glOrtho(-width, width, -height, height, -5000, 5000);
}

void
display(void)
{
    int i, j;

    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity ();

    glPushMatrix();
        glRotatef(spin_x, 0, 1, 0);
        glRotatef(spin_y, 1, 0, 0);
    
        glMatrixMode(GL_PROJECTION);
        glLoadIdentity ();

        glPushMatrix();
            gluPerspective (70, w / h, 0.8, 5000);
            glTranslatef(0, 0, spin_z);

            //calls move which moves individual points in clump
            move();
            //calls moveclump function which moves the entire clump
            moveclump();
            //draw the actual thing
            glBegin(GL_LINES);
            glColor3ub(0, 150, 50);
            //repeats for number of clumps used
            for(i = 0; i < n; i++) 
                for(j = 0; j < object; j++)
                    glVertex3f(obj[i][j].pos[0], obj[i][j].pos[1], obj[i][j].pos[2]);
            glEnd();

        glPopMatrix();
    glPopMatrix();


    glutSwapBuffers();
}

void
idle(void)
{
    glutPostRedisplay();
}

void
bail(int code)
{
    free(obj);
    exit(code);
}

void
mouse(int button, int state, int x, int y)
{

    switch(button) {
        case 0:
            old_x = x - spin_x;
            old_y = y - spin_y;
            break;
        case 2:
            old_y = y - spin_z;
            move_z = (move_z ? 0 : 1);
    }
            

    glutPostRedisplay();

}

void 
motion(x, y) {

    if(!move_z) {
        spin_x = x - old_x;
        spin_y = y - old_y;
    } else {
        spin_z = y - old_y;
    }

    glutPostRedisplay();
}

void
initgal(void) {
    int i;

    free(s);
    free(obj);

    s = (clump *)malloc(sizeof(clump) * n);
    obj = (clump **)malloc(sizeof(clump *) * n);

    for(i = 0; i < n; i++)
        obj[i] = (clump*)malloc(sizeof(clump) * object);
}



void
keyboard(unsigned char key, int x, int y)
{
    static int old_x = 50;
    static int old_y = 50;
    static int old_width = 512;
    static int old_height = 512;

    switch (key) {
        case 27:
                bail(0);
            break;
        case '0':
                init();
                break;
        case 'w':
                glutPositionWindow(old_x, old_y);
                glutReshapeWindow(old_width, old_height);
            break;
        case 'f':
            if (glutGet(GLUT_WINDOW_WIDTH) < glutGet(GLUT_SCREEN_WIDTH)) {
                old_x = glutGet(GLUT_WINDOW_X);
                old_y = glutGet(GLUT_WINDOW_Y);
                old_width = glutGet(GLUT_WINDOW_WIDTH);
                old_height = glutGet(GLUT_WINDOW_HEIGHT);
                glutFullScreen();
            }
            break;
//allows user to change number of clumps (only 1-9)
        case '1':
            n = 1;
            initgal();
            init();
            break;
        case '2':
            n = 2;
            initgal();
            init();
            break;
        case '3':
            n = 3;
            initgal();
            init();
            break;
        case '4':
            n = 4;
            initgal();
            init();
            break;
        case '5':
            n = 5;
            initgal();
            init();
            break;
        case '6':
            n = 6;
            initgal();
            init();
            break;
        case '7':
            n = 7;
            initgal();
            init();
            break;
        case '8':
            n = 8;
            initgal();
            init();
            break;
        case '9':
            n = 9;
            initgal();
            init();
            break;
    }
}


void init(void) {
    int i, j;
    float dy, dx, dist;

    for(i = 0; i < n; i++) {
        s[i].pos[0] =  (rand()%2 ? -1 : 1)*rand()%w/2;
        s[i].pos[1] =  (rand()%2 ? -1 : 1)*rand()%h/2;
        s[i].pos[2] =  (rand()%2 ? -1 : 1)*rand()%w/2;
        s[i].vel[0] = 0;
        s[i].vel[1] = 0;
        s[i].vel[2] = 0;
        s[i].acc[0] = 0;
        s[i].acc[1] = 0;
        s[i].acc[2] = 0;
        s[i].mass = 1000;
    }



    for(j = 0; j < n; j++) {
        for(i = 0; i < object; i++) {
            
            obj[j][i].pos[0] = s[j].pos[0] + (rand()%2 ? -1 : 1) * rand()%w/4;
            obj[j][i].pos[1] = s[j].pos[1] + (rand()%2 ? -1 : 1) * rand()%h/4;
            obj[j][i].pos[2] = s[j].pos[2] + (rand()%2 ? -1 : 1) * rand()%w;

            dist = sqrt( pow(obj[j][i].pos[0] - s[j].pos[0], 2) +
                        pow(obj[j][i].pos[1] - s[j].pos[1], 2) +
                        pow(obj[j][i].pos[2] - s[j].pos[2], 2));
    
            if(dist > w/6 || dist > h/6) {
                i--;
                continue;
            }

            obj[j][i].pos[2] = s[j].pos[2] + (rand()%2 ? -1 : 1) * (rand()%w*50)/(dist*dist);
        
            dx = obj[j][i].pos[0] - s[j].pos[0];
            dy = obj[j][i].pos[1] - s[j].pos[1];

            dist = sqrt(dx*dx + dy*dy);
    
            obj[j][i].vel[0] = -(dy*1.6 + s[j].vel[0])/dist;
            obj[j][i].vel[1] =  (dx*1.6 + s[j].vel[1])/dist;
            obj[j][i].vel[2] =  0;
    
            obj[j][i].acc[0] = obj[j][i].acc[1] = obj[j][i].acc[2] = 0;
            obj[j][i].mass = 1;
        }    
    }
}

int
main(int argc, char** argv)
{
    int i;

    srand(time(NULL));

    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
    glutInitWindowPosition(50, 50);
    glutInitWindowSize(512, 512);
    glutInit(&argc, argv);

    glutCreateWindow("magnets");
    glutDisplayFunc(display);
    glutReshapeFunc(reshape);

    glutKeyboardFunc(keyboard);
    glutMouseFunc(mouse);
    glutMotionFunc(motion);

    glEnable (GL_DEPTH_TEST);

    if (argc == 3) {
        sscanf(argv[1], "%d", &object);
        sscanf(argv[2], "%d", &n);
    } else if(argc == 2) {
        if (strcmp(argv[1], "-h") == 0) {
            fprintf(stderr, "%s [points] [clumps]\n", argv[0]);
            exit(0);
        }
        sscanf(argv[1], "%d", &object);
    }


    initgal();


    h = w = 512;

    init();

    glutIdleFunc(idle);
    glutMainLoop();
    return 0;
}
